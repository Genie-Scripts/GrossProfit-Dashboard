# html_generator.py
import pandas as pd
import json
from datetime import datetime

def format_rate(rate):
    """達成率をフォーマットする補助関数"""
    if pd.isna(rate):
        return "---"
    return f"{rate:.1f}%"

def get_performance_class(rate):
    """達成率に基づいてパフォーマンスクラスを返す"""
    if pd.isna(rate):
        return "info"
    elif rate >= 100:
        return "success"
    elif rate >= 90:
        return "warning"
    else:
        return "danger"

def generate_html(summary_df, chart_df):
    """
    サマリーとチャートデータからインタラクティブなHTMLレポートを生成する。
    Streamlit-OR-Dashboard風の統一デザインを適用。
    """
    # 1. チャート用データをJavaScriptが扱いやすいJSON形式に変換
    chart_json_data = {}
    for dept_name, group in chart_df.groupby('診療科'):
        group['月'] = group['月'].dt.strftime('%Y-%m-%d')
        chart_json_data[dept_name] = group.to_dict('records')
    
    chart_json_string = json.dumps(chart_json_data, ensure_ascii=False)

    # 2. HTMLのカード部分を生成（新デザインシステム適用）
    cards_html = ""
    for index, row in summary_df.iterrows():
        # パフォーマンスクラスの決定（直近月達成率ベース）
        perf_class = get_performance_class(row['直近月達成率'])
        
        # ランクバッジのスタイル設定
        rank_badge_class = "rank-badge-gold" if index == 0 else "rank-badge-silver" if index == 1 else "rank-badge-bronze" if index == 2 else ""
        
        # プログレスバーの幅計算（100%を上限）
        progress_width = min(row['直近月達成率'], 100) if pd.notna(row['直近月達成率']) else 0
        
        # トレンドアイコンの設定
        trend_icon = ""
        if row['評価コメント'] == "改善傾向 👍":
            trend_icon = '<span class="trend-icon up">↑</span>'
        elif row['評価コメント'] == "悪化傾向 👎":
            trend_icon = '<span class="trend-icon down">↓</span>'
        else:
            trend_icon = '<span class="trend-icon neutral">→</span>'
        
        cards_html += f"""
        <div class="metric-card {perf_class}" onclick="showChart('{row['診療科']}')">
            <div class="rank-badge {rank_badge_class}">#{index + 1}</div>
            <div class="metric-title">{row['診療科']}</div>
            
            <div class="achievement-highlight">
                <div class="achievement-label">直近月達成率</div>
                <div class="achievement-value">{format_rate(row['直近月達成率'])}</div>
                {trend_icon}
            </div>
            
            <div class="progress-bar">
                <div class="progress-fill" style="width: {progress_width}%"></div>
            </div>
            
            <div class="metric-details">
                <div class="metric-row">
                    <span>今年度平均</span>
                    <span class="metric-value-row">{format_rate(row['今年度平均達成率'])}</span>
                </div>
                <div class="metric-row">
                    <span>過去6ヶ月平均</span>
                    <span class="metric-value-row">{format_rate(row['過去6ヶ月平均達成率'])}</span>
                </div>
            </div>
        </div>
        """

    # 統計サマリーの計算
    total_depts = len(summary_df)
    achieved_depts = len(summary_df[summary_df['直近月達成率'] >= 100])
    avg_achievement = summary_df['直近月達成率'].mean()
    
    # 3. HTML全体のテンプレートを作成（Streamlit-OR-Dashboard風デザインシステム）
    html_template = f"""
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>診療科別 入外粗利レポート</title>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
    <style>
        /* === CSS変数定義（デザインシステム） === */
        :root {{
            --primary-color: #2E7CF6;
            --primary-dark: #1A5CC7;
            --success-color: #22C55E;
            --warning-color: #F59E0B;
            --danger-color: #EF4444;
            --info-color: #6B7280;
            --text-primary: #1F2937;
            --text-secondary: #6B7280;
            --text-light: #F9FAFB;
            --bg-primary: #FFFFFF;
            --bg-secondary: #F3F4F6;
            --border-radius: 12px;
            --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.12);
            --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            --card-padding: 24px;
            --card-gap: 20px;
        }}
        
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: linear-gradient(135deg, #EBF5FF 0%, #F3F4F6 100%);
            min-height: 100vh;
            color: var(--text-primary);
            line-height: 1.6;
        }}
        
        .container {{
            max-width: 1400px;
            margin: 0 auto;
            padding: 40px 20px;
        }}
        
        /* === ヘッダー === */
        .header {{
            text-align: center;
            margin-bottom: 40px;
            background: white;
            padding: 32px;
            border-radius: 16px;
            box-shadow: var(--shadow-md);
            position: relative;
        }}
        
        /* === ポータルへ戻るボタン === */
        .portal-home-button {{
            position: absolute;
            top: 20px;
            left: 20px;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
            padding: 10px 20px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: var(--transition);
            border: 2px solid rgba(255, 255, 255, 0.2);
            display: inline-flex;
            align-items: center;
            gap: 6px;
            box-shadow: var(--shadow-sm);
        }}
        
        .portal-home-button:hover {{
            background: linear-gradient(135deg, var(--primary-dark), var(--primary-color));
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
            border-color: rgba(255, 255, 255, 0.4);
        }}
        
        h1 {{
            font-size: 2.5em;
            font-weight: 700;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 12px;
        }}
        
        .subtitle {{
            color: var(--text-secondary);
            font-size: 1.1em;
            margin-bottom: 24px;
        }}
        
        .timestamp {{
            color: var(--text-secondary);
            font-size: 0.9em;
            background: var(--bg-secondary);
            display: inline-block;
            padding: 6px 16px;
            border-radius: 20px;
        }}
        
        /* === 統計サマリー === */
        .summary-stats {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }}
        
        .stat-card {{
            background: white;
            padding: 20px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            text-align: center;
            border: 1px solid #E5E7EB;
        }}
        
        .stat-value {{
            font-size: 2em;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 8px;
        }}
        
        .stat-label {{
            font-size: 0.9em;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}
        
        /* === メインコンテンツエリア === */
        #homepage {{
            display: block;
        }}
        
        #chartpage {{
            display: none;
        }}
        
        /* === メトリクスカードグリッド === */
        .cards-container {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: var(--card-gap);
            margin-bottom: 40px;
        }}
        
        /* === 統一メトリクスカード === */
        .metric-card {{
            background: white;
            border-radius: var(--border-radius);
            padding: var(--card-padding);
            box-shadow: var(--shadow-sm);
            border: 1px solid #E5E7EB;
            cursor: pointer;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
            min-height: 220px;
        }}
        
        .metric-card:hover {{
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg);
        }}
        
        /* カラーインジケーター */
        .metric-card::before {{
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--info-color);
        }}
        
        .metric-card.success::before {{ background: var(--success-color); }}
        .metric-card.warning::before {{ background: var(--warning-color); }}
        .metric-card.danger::before {{ background: var(--danger-color); }}
        
        /* ランクバッジ */
        .rank-badge {{
            position: absolute;
            top: 16px;
            right: 16px;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 0.9em;
            background: var(--bg-secondary);
            color: var(--text-secondary);
        }}
        
        .rank-badge-gold {{
            background: linear-gradient(135deg, #FFD700, #FFA500);
            color: white;
            box-shadow: 0 2px 8px rgba(255, 215, 0, 0.4);
        }}
        
        .rank-badge-silver {{
            background: linear-gradient(135deg, #C0C0C0, #808080);
            color: white;
            box-shadow: 0 2px 8px rgba(192, 192, 192, 0.4);
        }}
        
        .rank-badge-bronze {{
            background: linear-gradient(135deg, #CD7F32, #8B4513);
            color: white;
            box-shadow: 0 2px 8px rgba(205, 127, 50, 0.4);
        }}
        
        /* メトリックタイトル */
        .metric-title {{
            font-size: 1.2em;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 20px;
            padding-right: 50px;
        }}
        
        /* 達成率ハイライト（最重要指標） */
        .achievement-highlight {{
            background: linear-gradient(135deg, var(--bg-secondary), white);
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border: 2px solid var(--bg-secondary);
        }}
        
        .achievement-label {{
            font-size: 0.9em;
            color: var(--text-secondary);
            font-weight: 500;
        }}
        
        .achievement-value {{
            font-size: 2em;
            font-weight: 700;
            color: var(--text-primary);
        }}
        
        .metric-card.success .achievement-value {{ color: var(--success-color); }}
        .metric-card.warning .achievement-value {{ color: var(--warning-color); }}
        .metric-card.danger .achievement-value {{ color: var(--danger-color); }}
        
        /* トレンドアイコン */
        .trend-icon {{
            font-size: 1.5em;
            font-weight: 700;
            padding: 4px 8px;
            border-radius: 6px;
        }}
        
        .trend-icon.up {{
            color: var(--success-color);
            background: rgba(34, 197, 94, 0.1);
        }}
        
        .trend-icon.down {{
            color: var(--danger-color);
            background: rgba(239, 68, 68, 0.1);
        }}
        
        .trend-icon.neutral {{
            color: var(--info-color);
            background: rgba(107, 114, 128, 0.1);
        }}
        
        /* プログレスバー */
        .progress-bar {{
            background-color: #F3F4F6;
            border-radius: 6px;
            height: 8px;
            overflow: hidden;
            margin-bottom: 16px;
        }}
        
        .progress-fill {{
            height: 100%;
            border-radius: 6px;
            background: var(--info-color);
            transition: width 0.5s ease;
        }}
        
        .metric-card.success .progress-fill {{ background: var(--success-color); }}
        .metric-card.warning .progress-fill {{ background: var(--warning-color); }}
        .metric-card.danger .progress-fill {{ background: var(--danger-color); }}
        
        /* メトリック詳細 */
        .metric-details {{
            border-top: 1px solid var(--bg-secondary);
            padding-top: 12px;
        }}
        
        .metric-row {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9em;
            margin-bottom: 8px;
        }}
        
        .metric-row span:first-child {{
            color: var(--text-secondary);
            font-weight: 500;
        }}
        
        .metric-value-row {{
            font-weight: 600;
            color: var(--text-primary);
        }}
        
        /* === チャートページ === */
        #backButton {{
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1em;
            font-weight: 600;
            margin-bottom: 24px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: var(--transition);
            box-shadow: var(--shadow-md);
        }}
        
        #backButton:hover {{
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }}
        
        #chart-title {{
            font-size: 1.8em;
            color: var(--text-primary);
            margin-bottom: 24px;
            font-weight: 700;
        }}
        
        #chart-container {{
            background: white;
            padding: 32px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-md);
            min-height: 500px;
        }}
        
        /* レスポンシブデザイン */
        @media (max-width: 768px) {{
            .cards-container {{
                grid-template-columns: 1fr;
            }}
            
            .summary-stats {{
                grid-template-columns: 1fr;
            }}
            
            h1 {{
                font-size: 1.8em;
            }}
            
            .header {{
                padding-top: 60px;
            }}
            
            .portal-home-button {{
                top: 15px;
                left: 15px;
                padding: 8px 16px;
                font-size: 12px;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div id="homepage">
            <div class="header">
                <a href="./index.html" class="portal-home-button">🏠 ポータルTOPへ</a>
                <h1>診療科別 入外粗利レポート</h1>
                <p class="subtitle">2025年度診療科目標達成率の推移</p>
                <span class="timestamp">📅 {datetime.now().strftime('%Y年%m月%d日 %H:%M')} 更新</span>
            </div>
            
            <div class="summary-stats">
                <div class="stat-card">
                    <div class="stat-value">{total_depts}</div>
                    <div class="stat-label">診療科数</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">{achieved_depts}</div>
                    <div class="stat-label">目標達成</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">{avg_achievement:.1f}%</div>
                    <div class="stat-label">平均達成率</div>
                </div>
            </div>
            
            <div class="cards-container">
                {cards_html}
            </div>
        </div>

        <div id="chartpage">
            <button id="backButton" onclick="showHome()">
                <span>←</span>
                <span>ダッシュボードに戻る</span>
            </button>
            <h2 id="chart-title"></h2>
            <div id="chart-container"></div>
        </div>
    </div>

    <script>
        // Pythonから埋め込まれたデータ
        const chartData = {chart_json_string};

        const homePageDiv = document.getElementById('homepage');
        const chartPageDiv = document.getElementById('chartpage');
        const chartTitle = document.getElementById('chart-title');

        function showChart(deptName) {{
            homePageDiv.style.display = 'none';
            chartPageDiv.style.display = 'block';
            chartTitle.innerText = deptName + ' - 達成率推移';

            const data = chartData[deptName];
            if (!data) return;

            const dates = data.map(d => d['月']);
            const rates = data.map(d => d['達成率']);

            // 線形回帰の計算
            function calculateLinearRegression(x, y) {{
                const n = x.length;
                let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
                
                for (let i = 0; i < n; i++) {{
                    const xi = i; // インデックスを使用
                    sumX += xi;
                    sumY += y[i];
                    sumXY += xi * y[i];
                    sumX2 += xi * xi;
                }}
                
                const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
                const intercept = (sumY - slope * sumX) / n;
                
                return {{ slope, intercept }};
            }}
            
            // 回帰線のデータを生成
            const regression = calculateLinearRegression(dates, rates);
            const regressionY = dates.map((_, i) => regression.intercept + regression.slope * i);
            
            // メインのトレースライン（直線）
            const trace = {{
                x: dates,
                y: rates,
                mode: 'lines+markers',
                type: 'scatter',
                name: '達成率',
                line: {{
                    color: '#2E7CF6',
                    width: 3,
                    shape: 'linear'  // 直線に変更
                }},
                marker: {{
                    size: 8,
                    color: '#2E7CF6',
                    line: {{
                        color: 'white',
                        width: 2
                    }}
                }},
                hovertemplate: '<b>%{{x|%Y年%m月}}</b><br>達成率: %{{y:.1f}}%<extra></extra>'
            }};
            
            // 回帰線のトレース
            const regressionTrace = {{
                x: dates,
                y: regressionY,
                mode: 'lines',
                type: 'scatter',
                name: 'トレンド',
                line: {{
                    color: '#6B7280',
                    width: 2,
                    dash: 'dot'  // 点線
                }},
                hovertemplate: '<b>%{{x|%Y年%m月}}</b><br>トレンド: %{{y:.1f}}%<extra></extra>'
            }};
            
            // Y軸の範囲を計算（最小値と最大値に余裕を持たせる）
            const minRate = Math.min(...rates);
            const maxRate = Math.max(...rates);
            const yPadding = (maxRate - minRate) * 0.1 || 10; // 10%の余白または最小10
            const yMin = Math.max(0, minRate - yPadding); // 0以下にはしない
            const yMax = maxRate + yPadding;
            
            // グラフレイアウト
            const layout = {{
                title: {{
                    text: deptName + ' の達成率推移',
                    font: {{ size: 20, family: 'sans-serif' }}
                }},
                xaxis: {{
                    title: '期間',
                    showgrid: true,
                    gridcolor: '#F3F4F6',
                    tickformat: '%Y/%m',
                    tickangle: -45
                }},
                yaxis: {{
                    title: '達成率 (%)',
                    tickformat: '.1f',
                    showgrid: true,
                    gridcolor: '#F3F4F6',
                    range: [yMin, yMax]  // データに基づいた範囲設定
                }},
                margin: {{ t: 60, l: 70, r: 40, b: 80 }},
                plot_bgcolor: '#FAFAFA',
                paper_bgcolor: 'white',
                hovermode: 'x unified',
                hoverlabel: {{
                    bgcolor: 'white',
                    font: {{ size: 14 }},
                    bordercolor: '#E5E7EB'
                }},
                shapes: [
                    {{
                        type: 'line',
                        x0: dates[0],
                        y0: 100,
                        x1: dates[dates.length - 1],
                        y1: 100,
                        line: {{
                            color: '#EF4444',
                            width: 2,
                            dash: 'dash'
                        }}
                    }}
                ],
                annotations: [
                    {{
                        x: dates[dates.length - 1],
                        y: 100,
                        xref: 'x',
                        yref: 'y',
                        text: '目標ライン (100%)',
                        showarrow: false,
                        xanchor: 'right',
                        yanchor: 'bottom',
                        font: {{
                            size: 12,
                            color: '#EF4444'
                        }},
                        bgcolor: 'rgba(255, 255, 255, 0.8)',
                        borderpad: 4
                    }}
                ],
                legend: {{
                    orientation: 'h',
                    yanchor: 'bottom',
                    y: 1.02,
                    xanchor: 'right',
                    x: 1
                }}
            }};
            
            const config = {{
                responsive: true,
                displayModeBar: true,
                displaylogo: false,
                modeBarButtonsToRemove: ['pan2d', 'select2d', 'lasso2d', 'autoScale2d']
            }};

            Plotly.newPlot('chart-container', [trace, regressionTrace], layout, config);
        }}

        function showHome() {{
            homePageDiv.style.display = 'block';
            chartPageDiv.style.display = 'none';
        }}
        
        // ページロード時のアニメーション
        window.addEventListener('load', () => {{
            const cards = document.querySelectorAll('.metric-card');
            cards.forEach((card, index) => {{
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                setTimeout(() => {{
                    card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }}, index * 50);
            }});
        }});
    </script>
</body>
</html>
    """
    
    return html_template